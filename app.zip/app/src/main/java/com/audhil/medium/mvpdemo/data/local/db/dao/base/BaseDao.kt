package com.audhil.medium.mvpdemo.data.local.db.dao.base

/*
 * Created by mohammed-2284 on 01/05/18.
 */

abstract class BaseDao {
    abstract fun deleteTable()  //  reminder to developer to delete Table
}