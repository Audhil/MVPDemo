package com.audhil.medium.mvpdemo.glide;

/*
 * Created by mohammed-2284 on 29/04/18.
 */

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MovieDBAppGlideModule extends AppGlideModule {
}