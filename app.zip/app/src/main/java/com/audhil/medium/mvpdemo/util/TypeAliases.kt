package com.audhil.medium.mvpdemo.util

/*
 * Created by mohammed-2284 on 11/04/18.
 */

typealias CallBack<T> = (T) -> Unit

typealias BiCallBack<T, V> = (T, V) -> Unit